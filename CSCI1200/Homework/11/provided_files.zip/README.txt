EXTRA CREDIT HOMEWORK: DEBUGGING

NAME:  < insert name >



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < insert # hours >



GOAL:
< if you partially or completely decrypted the goal, paste it here >



COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(TAs, ALAC tutors, upperclassmen, students/instructor via LMS,
etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< insert collaborators / resources >

Remember: All finding and fixing bugs for this assignment must be
done on your own, as described in "Academic Integrity for Homework"
handout.



EXTRA CREDIT:
List any bugs you found that did not or should not affect the normal execution
of the program. (These should also go in your writeup.)



MISC. COMMENTS TO GRADER:
Optional, please be concise!
