var searchData=
[
  ['release_20notes_20for_20version_201_2e9_2e1',['Release Notes for Version 1.9.1',['../page_release_notes.html',1,'']]],
  ['replaced_20routines',['Replaced Routines',['../page_replace.html',1,'page_reports']]],
  ['running_20dr_2e_20memory',['Running Dr. Memory',['../page_running.html',1,'']]],
  ['reg',['reg',['../struct__drsys__arg__t.html#a51d3fef5c9cf6cf3e73857c75ff0beab',1,'_drsys_arg_t']]]
];
