var searchData=
[
  ['ordinal',['ordinal',['../struct__drsys__arg__t.html#abc5ce057f70278ea43ba58df7832ebac',1,'_drsys_arg_t']]],
  ['obtaining_20help_20and_20reporting_20bugs',['Obtaining Help and Reporting Bugs',['../page_help.html',1,'']]]
];
