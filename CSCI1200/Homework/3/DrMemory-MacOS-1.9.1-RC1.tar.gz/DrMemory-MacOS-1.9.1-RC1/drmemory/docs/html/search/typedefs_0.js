var searchData=
[
  ['app_5fmemory_5fcreate_5fcb_5ft',['app_memory_create_cb_t',['../group__umbra.html#ga195d46bcf5438dbef20889b9a24a10f4',1,'umbra.h']]]
];
