var globals_dup =
[
    [ "a", "globals.html", null ],
    [ "d", "globals_d.html", null ],
    [ "s", "globals_s.html", null ],
    [ "u", "globals_u.html", null ]
];