var page_tools =
[
    [ "System Call Tracer for Windows", "page_drstrace.html", [
      [ "Child Processes", "page_drstrace.html#sec_drstrace_child", null ],
      [ "Symbol Usage", "page_drstrace.html#sec_drstrace_symfetch", null ],
      [ "Limitations", "page_drstrace.html#sec_drstrace_limits", [
        [ "Window of Tracing", "page_drstrace.html#sec_drstrace_window", null ],
        [ "Windows XP and 2000 Console Output", "page_drstrace.html#sec_drstrace_console", null ]
      ] ]
    ] ],
    [ "Symbol Query Tool", "page_symquery.html", null ]
];