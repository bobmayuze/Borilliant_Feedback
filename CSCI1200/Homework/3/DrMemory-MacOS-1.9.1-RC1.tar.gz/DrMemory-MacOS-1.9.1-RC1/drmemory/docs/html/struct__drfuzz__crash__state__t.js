var struct__drfuzz__crash__state__t =
[
    [ "thread_count", "struct__drfuzz__crash__state__t.html#a1d0532775449a99c9ee30003afae9209", null ],
    [ "thread_states", "struct__drfuzz__crash__state__t.html#aadcdc1060669ad19179b35b0d2c7a87e", null ]
];