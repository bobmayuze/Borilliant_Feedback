var searchData=
[
  ['installing_20dr_2e_20memory',['Installing Dr. Memory',['../page_install.html',1,'']]],
  ['installing_20on_20android',['Installing on Android',['../page_install_android.html',1,'page_install']]],
  ['installing_20on_20linux',['Installing on Linux',['../page_install_linux.html',1,'page_install']]],
  ['installing_20on_20mac',['Installing on Mac',['../page_install_macos.html',1,'page_install']]],
  ['installing_20on_20windows',['Installing on Windows',['../page_install_windows.html',1,'page_install']]],
  ['invalid_20heap_20argument',['Invalid Heap Argument',['../page_invarg.html',1,'page_types']]]
];
