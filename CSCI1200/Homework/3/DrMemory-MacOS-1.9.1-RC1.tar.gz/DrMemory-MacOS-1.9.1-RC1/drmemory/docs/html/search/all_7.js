var searchData=
[
  ['handle_20leaks',['Handle Leaks',['../page_handle.html',1,'page_types']]]
];
