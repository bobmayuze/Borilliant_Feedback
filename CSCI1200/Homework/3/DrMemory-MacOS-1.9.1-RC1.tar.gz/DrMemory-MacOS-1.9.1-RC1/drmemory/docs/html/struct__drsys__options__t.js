var struct__drsys__options__t =
[
    [ "analyze_unknown_syscalls", "struct__drsys__options__t.html#a98bced7cd4296b8074f922cc529e9e3a", null ],
    [ "is_byte_addressable", "struct__drsys__options__t.html#a1f30dd7b207eafe64e64579c08640586", null ],
    [ "is_byte_defined", "struct__drsys__options__t.html#adbc0b695366702f728afcdb6f2bfc02d", null ],
    [ "is_byte_undefined", "struct__drsys__options__t.html#a6af83ea3b86735fc827cbd077354e006", null ],
    [ "is_register_defined", "struct__drsys__options__t.html#aef13bb58c1b8027615248c2c4c64cbcc", null ],
    [ "lookup_internal_symbol", "struct__drsys__options__t.html#a379aaee94dc8b833717e74598f0b72d7", null ],
    [ "struct_size", "struct__drsys__options__t.html#ac35d3a3a7f5dd5f266b95d8bdb1d948d", null ],
    [ "syscall_driver", "struct__drsys__options__t.html#acf96eea8b757c1cf5cf9cc5ebf1dad54", null ],
    [ "syscall_dword_granularity", "struct__drsys__options__t.html#a8dafc6a6995f1c11438e200ab130ef6c", null ],
    [ "syscall_sentinels", "struct__drsys__options__t.html#a0903b4a6615e8f83fbe60a2211750675", null ],
    [ "verify_sysnums", "struct__drsys__options__t.html#a918698345d3cd7e63847afceb00401d3", null ]
];