var searchData=
[
  ['shadow_5fiterate_5ffunc_5ft',['shadow_iterate_func_t',['../group__umbra.html#gaca4a2c42754ea20aa90b94c4b5eb5674',1,'umbra.h']]]
];
