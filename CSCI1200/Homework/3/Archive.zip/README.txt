HOMEWORK 3: DYNAMIC TETRIS ARRAYS


NAME:  Ziniu Yu


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

	LMS
	c++.com >> find sth about random function
	google

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  20+



MISC. COMMENTS TO GRADER:  
Optional, please be concise!

	I apologize for the super long output for my own test cases
	because of the use of random function. And there are some
	more I want to say in the very ending of my output.

	To be honest, my random tetris test case reveals lots of
	bugs which I haven’t thought of, and those bugs will probably
	produce lots of memory errors.

